USE [ChinaHCP]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO


/****** Object:  Table [dbo].[WechatMITradeProduct]    Script Date: 2014/11/19 14:28:08 ******/


CREATE TABLE [dbo].[WechatMITradeProduct](
	[WechatMITradeProductID] [uniqueidentifier] NOT NULL,
	[TradeNameEN] [varchar](100) NOT NULL,
	[TradeNameZH] [nvarchar](100) NOT NULL,
	[TradeNameUS] [varchar](100) NOT NULL,
	[IsActive] [bit] NOT NULL,
	[TradeNamePinYin] [varchar](100) NULL,
	[GenericNameEN] [varchar](100) NULL,
	[GenericNameZH] [nvarchar](100) NULL,
	[GenericNamePinYin] [varchar](100) NULL,
	[DiseaseAreaID] [uniqueidentifier] NULL,
	[RowVersion] [timestamp] NOT NULL,
 CONSTRAINT [PK_WechatTradeProduct] PRIMARY KEY CLUSTERED 
(
	[WechatMITradeProductID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[WechatMITradeProduct] ADD  CONSTRAINT [DF_WechatMITradeProduct_IsActive]  DEFAULT ((1)) FOR [IsActive]
GO

ALTER TABLE [dbo].[WechatMITradeProduct]  WITH CHECK ADD  CONSTRAINT [FK_WechatMITradeProduct_DiseaseArea] FOREIGN KEY([DiseaseAreaID])
REFERENCES [dbo].[DiseaseArea] ([DiseaseAreaID])
GO

ALTER TABLE [dbo].[WechatMITradeProduct] CHECK CONSTRAINT [FK_WechatMITradeProduct_DiseaseArea]
GO



/****** Object:  Table [dbo].[WechatMIQuestion]    Script Date: 2014/11/19 14:29:08 ******/
CREATE TABLE [dbo].[WechatMIQuestion](
	[WechatMIQuestionID] [uniqueidentifier] NOT NULL,
	[AutoNo] [bigint] IDENTITY(1,1) NOT NULL,
	[QuestionUID] [varchar](32) NULL,
	[NTID] [nvarchar](50) NOT NULL,
	[Email] [nvarchar](200) NULL,
	[Phone] [nvarchar](20) NULL,
	[Department] [nvarchar](100) NULL,
	[FullName] [nvarchar](100) NULL,
	[HcpID] [uniqueidentifier] NULL,
	[HcpFullName] [nvarchar](100) NOT NULL,
	[HcpHospital] [nvarchar](255) NULL,
	[HcpDeptCode] [nvarchar](50) NULL,
	[HcpDepartment] [nvarchar](100) NULL,
	[HcpProvinceCHS] [nvarchar](255) NULL,
	[HcpProvince] [nvarchar](255) NULL,
	[HcpCity] [nvarchar](255) NULL,
	[HcpPhone] [nvarchar](20) NULL,
	[HcpEmail] [varchar](255) NULL,
	[WechatMITradeProductID] [uniqueidentifier] NULL,
	[ProductCode] [varchar](100) NULL,
	[ProductNameZH] [nvarchar](100) NULL,
	[Question] [nvarchar](max) NULL,
	[SendStatus] [int] NULL,
	[CreatedDateET] [datetime] NOT NULL,
	[CreatedDateUtc] [datetime] NOT NULL,
	[CreatedBy] [nchar](50) NULL,
	[CreatedOn] [datetime] NOT NULL,
	[ModifiedBy] [nchar](50) NULL,
	[ModifiedOn] [datetime] NOT NULL,
	[RowVersion] [timestamp] NOT NULL,
	[Source] [nvarchar](50) NOT NULL,
 CONSTRAINT [PK_WechatMIQuestion] PRIMARY KEY CLUSTERED 
(
	[WechatMIQuestionID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[WechatMIQuestion] ADD  CONSTRAINT [DF_WechatMIQuestion_WechatMIQuestionID]  DEFAULT (newid()) FOR [WechatMIQuestionID]
GO

ALTER TABLE [dbo].[WechatMIQuestion] ADD  CONSTRAINT [DF_WechatMIQuestion_Phone]  DEFAULT (N'') FOR [Phone]
GO

ALTER TABLE [dbo].[WechatMIQuestion] ADD  CONSTRAINT [DF_WechatMIQuestion_Department]  DEFAULT (N'') FOR [Department]
GO

ALTER TABLE [dbo].[WechatMIQuestion] ADD  CONSTRAINT [DF_WechatMIQuestion_FullName]  DEFAULT (N'') FOR [FullName]
GO

ALTER TABLE [dbo].[WechatMIQuestion] ADD  CONSTRAINT [DF_WechatMIQuestion_CreatedDateET]  DEFAULT (switchoffset(sysdatetimeoffset(),'-05:00')) FOR [CreatedDateET]
GO

ALTER TABLE [dbo].[WechatMIQuestion] ADD  CONSTRAINT [DF_WechatMIQuestion_CreatedDateUtc]  DEFAULT (switchoffset(sysdatetimeoffset(),'+00:00')) FOR [CreatedDateUtc]
GO

ALTER TABLE [dbo].[WechatMIQuestion] ADD  CONSTRAINT [DF_WechatMIQuestion_CreatedOn]  DEFAULT (getdate()) FOR [CreatedOn]
GO

ALTER TABLE [dbo].[WechatMIQuestion] ADD  CONSTRAINT [DF_WechatMIQuestion_ModifiedOn]  DEFAULT (getdate()) FOR [ModifiedOn]
GO

ALTER TABLE [dbo].[WechatMIQuestion] ADD  CONSTRAINT [DF_WechatMIQuestion_Source]  DEFAULT (N'ChinaWechat') FOR [Source]
GO

ALTER TABLE [dbo].[WechatMIQuestion]  WITH CHECK ADD  CONSTRAINT [FK_WechatMIQuestion_HcpID] FOREIGN KEY([HcpID])
REFERENCES [dbo].[Hcp] ([HcpID])
GO

ALTER TABLE [dbo].[WechatMIQuestion] CHECK CONSTRAINT [FK_WechatMIQuestion_HcpID]
GO

ALTER TABLE [dbo].[WechatMIQuestion]  WITH NOCHECK ADD  CONSTRAINT [FK_WechatMIQuestion_WechatMITradeProductID] FOREIGN KEY([WechatMITradeProductID])
REFERENCES [dbo].[WechatMITradeProduct] ([WechatMITradeProductID])
NOT FOR REPLICATION 
GO

ALTER TABLE [dbo].[WechatMIQuestion] NOCHECK CONSTRAINT [FK_WechatMIQuestion_WechatMITradeProductID]
GO


/****** Object:  Index [IX_CreatedBy]    Script Date: 2014/11/19 14:53:56 ******/
CREATE NONCLUSTERED INDEX [IX_CreatedBy] ON [dbo].[WechatMIQuestion]
(
	[CreatedBy] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO


/****** Object:  Index [IX_CreatedOn]    Script Date: 2014/11/19 14:54:10 ******/
CREATE NONCLUSTERED INDEX [IX_CreatedOn] ON [dbo].[WechatMIQuestion]
(
	[CreatedOn] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO


/****** Object:  Index [IX_HcpDepartment]    Script Date: 2014/11/19 14:54:24 ******/
CREATE NONCLUSTERED INDEX [IX_HcpDepartment] ON [dbo].[WechatMIQuestion]
(
	[HcpDepartment] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO


/****** Object:  Index [IX_HcpFullName]    Script Date: 2014/11/19 14:54:35 ******/
CREATE NONCLUSTERED INDEX [IX_HcpFullName] ON [dbo].[WechatMIQuestion]
(
	[HcpFullName] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

/****** Object:  Index [IX_HcpHospital]    Script Date: 2014/11/19 14:54:45 ******/
CREATE NONCLUSTERED INDEX [IX_HcpHospital] ON [dbo].[WechatMIQuestion]
(
	[HcpHospital] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO


/****** Object:  Index [IX_HcpProvince]    Script Date: 2014/11/19 14:54:56 ******/
CREATE NONCLUSTERED INDEX [IX_HcpProvince] ON [dbo].[WechatMIQuestion]
(
	[HcpProvince] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO


/****** Object:  Index [IX_NTID]    Script Date: 2014/11/19 14:55:06 ******/
CREATE NONCLUSTERED INDEX [IX_NTID] ON [dbo].[WechatMIQuestion]
(
	[NTID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO


/****** Object:  Index [IX_ProductNameZH]    Script Date: 2014/11/19 14:55:17 ******/
CREATE NONCLUSTERED INDEX [IX_ProductNameZH] ON [dbo].[WechatMIQuestion]
(
	[ProductNameZH] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO


/****** Object:  Index [IX_SendStatus]    Script Date: 2014/11/19 14:55:29 ******/
CREATE NONCLUSTERED INDEX [IX_SendStatus] ON [dbo].[WechatMIQuestion]
(
	[SendStatus] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO



/****** Object:  StoredProcedure [dbo].[SP_ChinaWechatAddQuestion]    Script Date: 2014/11/25 13:04:30 ******/
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[SP_ChinaWechatAddQuestion]
	-- Add the parameters for the stored procedure here
	@NTID nvarchar(50),
	@Email nvarchar(200),
	@Phone nvarchar(20),
	@Department nvarchar(100),
	@FullName nvarchar(100),
	@HcpID uniqueidentifier,
	@HcpFullName nvarchar(100),
	@HcpHospital nvarchar(255),
	@HcpDeptCode nvarchar(50),
	@HcpDepartment nvarchar(100),
	@HcpProvinceCHS nvarchar(255),
	@HcpProvince nvarchar(255),
	@HcpCity nvarchar(255),
	@HcpPhone nvarchar(20),
	@HcpEmail varchar(255),
    @WechatMITradeProductID uniqueidentifier,
    @ProductCode varchar(100),
    @ProductNameZH nvarchar(100),
    @Question nvarchar(max),
    @SendStatus int,
    @CreatedBy nchar(50),
    @ModifiedBy nchar(50)

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	DECLARE @AutoNo BIGINT
	DECLARE	@QuestionUID VARCHAR(32)
	DECLARE @ID uniqueidentifier

	SELECT @ID=NEWID()


    -- Insert new question

	BEGIN TRANSACTION

	INSERT INTO [dbo].[WechatMIQuestion]
		([WechatMIQuestionID]
		,[NTID]
		,[Email]
		,[Phone]
		,[Department]
		,[FullName]
		,[HcpID]
		,[HcpFullName]
		,[HcpHospital]
		,[HcpDeptCode]
		,[HcpDepartment]
		,[HcpProvinceCHS]
		,[HcpProvince]
		,[HcpCity]
		,[HcpPhone]
		,[HcpEmail]
		,[WechatMITradeProductID]
		,[ProductCode]
		,[ProductNameZH]
		,[Question]
		,[SendStatus]
		,[CreatedBy]
		,[ModifiedBy])
     VALUES
        (@ID,
		@NTID,
		@Email,
		@Phone,
		@Department,
		@FullName,
		@HcpID,
		@HcpFullName,
		@HcpHospital,
		@HcpDeptCode,
		@HcpDepartment,
		@HcpProvinceCHS,
		@HcpProvince,
		@HcpCity,
		@HcpPhone,
		@HcpEmail,
		@WechatMITradeProductID,
		@ProductCode,
		@ProductNameZH,
		@Question,
		@SendStatus,
		@CreatedBy,
		@ModifiedBy)


		SELECT @AutoNo = AutoNo FROM [dbo].[WechatMIQuestion] WHERE [WechatMIQuestionID]=@ID
		--Set QuestionUID Prefix 
		SELECT @QuestionUID = 'ChinaWechat_'

		--Generate QuestionUID
		SET @QuestionUID = @QuestionUID +  RIGHT('00000000'+CAST(@AutoNo AS VARCHAR), 8) 
					
		--���±�� 
		UPDATE WechatMIQuestion SET QuestionUID = @QuestionUID WHERE [WechatMIQuestionID]=@ID		 

	COMMIT TRANSACTION
END

GO




/****** Object:  View [dbo].[view_ChinaWechatQuestion]    Script Date: 2014/11/19 14:33:23 ******/
CREATE VIEW [dbo].[view_ChinaWechatQuestion]
AS
SELECT   TOP (100) PERCENT WechatMIQuestionID, QuestionUID, AutoNo, NTID, Email, Phone, Department, FullName, HcpID, 
                HcpFullName, HcpHospital, HcpDeptCode, HcpDepartment, HcpCity, HcpProvince, HcpProvinceCHS,HcpPhone, HcpEmail, WechatMITradeProductID, 
                ProductCode, ProductNameZH, Question, SendStatus, CreatedDateET, CreatedDateUtc, Source, ModifiedOn
FROM      dbo.WechatMIQuestion
WHERE   (SendStatus = 0) OR
                (SendStatus = 2)
ORDER BY ModifiedOn




GO
/****** Object:  View [dbo].[view_ChinaWechatGetHcpInfoByFullName]    Script Date: 2014/11/19 14:34:12 ******/
CREATE VIEW [dbo].[view_ChinaWechatGetHcpInfoByFullName]
AS
SELECT 
	a.HcpID,
	a.FullName,
	a.Email,
	CASE WHEN a.HospitalID is null THEN a.OtherHospitalName
		ELSE b.NameCN END AS Hospital,
	CASE WHEN ISNULL(a.Cellphone,'') ='' THEN a.Telphone
		ELSE a.Cellphone END AS Phone,
	c.Chinese AS Province,
	d.SpecialtyCode AS DepartmentEN,
	d.NameZH AS DepartmentZH,
	e.NameCN AS City
FROM Hcp a
	LEFT JOIN Hospital b on a.HospitalID = b.HospitalID
	LEFT JOIN view_ProvinceMapping c on a.ProvinceID = c.ProvinceID
	LEFT JOIN view_SpecialtyMapping d on a.SpecialtyID  = d.SpecialtyID
	LEFT JOIN City e on b.CityID = e.CityID


GO


/****** Object:  View [dbo].[View_Question]    Script Date: 2014/11/19 14:34:36 ******/
ALTER VIEW [dbo].[View_Question]
AS

 SELECT 
	  NULL Sales_ID
	 ,NULL Sales_LastName
	 ,NULL Sales_Email
	 ,NULL Sales_Role
	 ,NULL Sales_OfficePhone
	 ,case when c.NameCN is not null then c.NameCN 
				else h.OtherHospitalName end Customer_Company
	 ,'CN' Customer_Country
	 ,h.Email Customer_Email
	 ,'Chinese' Customer_Language
	 ,h.FullName Customer_LastName
	 ,s.SpecialtyCode Customer_Specialty
	 ,p.Chinese Customer_State
	 ,NULL Customer_City
	 ,NULL Customer_OfficePhone
	 ,q.CreatedDateET MedicalInquiry_CreatedDate
	 ,q.ChinaHcpID MedicalInquiry_ID
	 ,q.Question MedicalInquiry_Inquiry
	 ,case when tp.TradeNameEN is not null then tp.TradeNameEN
				else 'NO PRODUCT - CN' end MedicalInquiry_ProductCode
	 ,'HCP Website' MedicalInquiry_SourceSystem
    FROM Question q left join TradeProduct tp on q.TradeProductID = tp.TradeProductID
         left join Hcp h on q.HcpID = h.HcpID
         left join ProvinceMapping p on h.ProvinceID = p.ProvinceMappingID
         left join SpecialtyMapping s on h.SpecialtyID = s.SpecialtyMappingID
         left join Hospital c on h.HospitalID = c.HospitalID
	 
	UNION ALL

         SELECT 
                            ISNULL([NTID],'') collate Chinese_PRC_CI_AS Sales_ID,       
                            ISNULL([FullName],'') collate Chinese_PRC_CI_AS Sales_LastName,
                            ISNULL([Email],'') collate Chinese_PRC_CI_AS Sales_Email,
                            ISNULL([Department],'') collate Chinese_PRC_CI_AS Sales_Role,
                            ISNULL([Phone],'') collate Chinese_PRC_CI_AS Sales_OfficePhone,
                            ISNULL([HcpHospital],'') collate Chinese_PRC_CI_AS Customer_Company,
                            'CN' collate Chinese_PRC_CI_AS Customer_Country ,
                            ISNULL([HcpEmail],'') collate Chinese_PRC_CI_AS Customer_Email,
                            'Chinese' collate Chinese_PRC_CI_AS Customer_Language,
                            ISNULL([HcpFullName],'')  collate Chinese_PRC_CI_AS Customer_LastName,
                            ISNULL([HcpDeptCode],'') collate Chinese_PRC_CI_AS Customer_Specialty,
                            ISNULL([HcpProvinceCHS],'') collate Chinese_PRC_CI_AS Customer_State,
                            ISNULL([HcpCity],'') collate Chinese_PRC_CI_AS Customer_City,
                            ISNULL([HcpPhone],'') collate Chinese_PRC_CI_AS Customer_OfficePhone,
                            [CreatedDateET] MedicalInquiry_CreatedDate,
                            [QuestionUID] collate Chinese_PRC_CI_AS MedicalInquiry_ID,
                            [Question] collate Chinese_PRC_CI_AS MedicalInquiry_Inquiry,
                            [ProductCode] collate Chinese_PRC_CI_AS MedicalInquiry_ProductCode,
                            'HCP Website' collate Chinese_PRC_CI_AS MedicalInquiry_SourceSystem
         FROM WechatMIQuestion



GO