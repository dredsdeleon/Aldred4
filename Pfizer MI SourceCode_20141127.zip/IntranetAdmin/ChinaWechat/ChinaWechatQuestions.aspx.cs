﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Drawing;

namespace ChinaHcp.Web.IntranetAdmin
{
    public partial class ChinaWechatQuestions : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                //this.txtStartDate.Text = DateTime.Today.AddMonths(-3).ToShortDateString();
                //this.txtStartDate.ReadOnly = true;
                //this.txtEndDate.Text = DateTime.Today.ToShortDateString();
                //this.txtEndDate.ReadOnly = true;
                this.grvQuestions.EmptyDataText = "Data Is Empty.";

                var dao = new ChinaHcp.DataAccess.ChinaWechat.WechatInfoDAO();

                //show table header
                //try
                //{
                //    //var result = dao.SearchWechatInfo("1=2");
                //    //if (result.Rows.Count == 0)
                //    //{
                //    //    result.Rows.Add(result.NewRow());
                //    //}
                //    //this.grvQuestions.DataSource = result;
                //    //this.grvQuestions.DataBind();


                //}
                //catch (Exception ex)
                //{
                //    throw ex;
                //}

                Session["ChinaWeChatSortExpression"] = null;
                Session["ChinaWeChatQuestionResults"] = null;
                this.grvQuestions.AllowSorting = false;

                this.btnExport.Enabled = false;
            }
        }


        protected void btnSearch_Click(object sender, EventArgs e)
        {
            this.grvQuestions.AllowSorting = true;

            string startdate = txtStartDate.Text;
            string enddate = txtEndDate.Text;
            string keyword = this.txtKeyWord.Text;
            string status = this.ddlstatus.Value;
            string openid = string.Empty;
            string NTID = this.txtNTID.Text;

            if (string.IsNullOrEmpty(status))
            {
                status = "-1";
            }
            string search = " (1=1) ";

            //filter by question owner
            if (!string.IsNullOrEmpty(NTID))
            {
                if (!string.IsNullOrEmpty(search))
                {
                    search += " AND ";
                }
                search = string.Format(" (NTID = '{0}') ", NTID);
            }

            //filter by question owner and question status

            if (status != "-1")
            {
                if (!string.IsNullOrEmpty(search))
                {
                    search += " AND ";
                }
                search = string.Format(" ( SendStatus={0}) ", status);
            }


            //fliter by date

            if (!string.IsNullOrEmpty(startdate))
            {
                if (!string.IsNullOrEmpty(search))
                {
                    search += " AND ";
                }
                startdate += " 00:00:000";
                search += string.Format(" {0} >= '{1}' ", "CreatedOn", startdate);
            }


            if (!string.IsNullOrEmpty(enddate))
            {
                if (!string.IsNullOrEmpty(search))
                {
                    search += " AND ";
                }
                enddate += " 23:59:59";
                search += string.Format(" {0} <= '{1}' ", "CreatedOn", enddate);
            }


            //as all parameter are same key word, so just need to check fullname
            string searchSql = string.Empty;
            if (!string.IsNullOrEmpty(keyword))
            {
                keyword = keyword.Replace("'", "''");

                searchSql += string.Format(" {0} LIKE '%{1}%' ", "HcpFullName", keyword);
                searchSql += " OR ";
                searchSql += string.Format(" {0} LIKE '%{1}%' ", "HcpHospital", keyword);
                searchSql += " OR ";
                searchSql += string.Format(" {0} LIKE '%{1}%' ", "HcpProvince", keyword);
                searchSql += " OR ";
                searchSql += string.Format(" {0} LIKE '%{1}%' ", "HcpDepartment", keyword);
                searchSql += " OR ";
                searchSql += string.Format(" {0} LIKE '%{1}%' ", "HcpCity", keyword);
                searchSql += " OR ";
                //searchSql += string.Format(" {0} LIKE '%{1}%' ", "ProductCode", keyword);
                //searchSql += " OR ";
                searchSql += string.Format(" {0} LIKE '%{1}%' ", "ProductNameZH", keyword);
                searchSql += " OR ";
                searchSql += string.Format(" {0} LIKE '%{1}%' ", "Question", keyword);

            }


            if (!string.IsNullOrEmpty(searchSql))
            {
                search = string.Format(" ({0}) AND ({1})", search, searchSql);
            }


            var dao = new ChinaHcp.DataAccess.ChinaWechat.WechatInfoDAO();

            try
            {
                var result = dao.SearchWechatInfo(search);
                if (result.Rows.Count == 0)
                {
                    result.Rows.Add(result.NewRow());
                    this.grvQuestions.Visible = false;
                    this.btnExport.Enabled = false;
                    this.SearchHeading.Text = "No question was found.";
                    this.SearchHeading.Visible = true;
                    this.lblCount.Text = string.Empty;
                }
                else
                {
                    this.grvQuestions.Visible = true;
                    this.btnExport.Enabled = true;
                    this.SearchHeading.Text = "Search Results";
                    this.SearchHeading.Visible = true;
                    this.lblCount.Text = "Total Records: " + result.Rows.Count.ToString();
                }
                Session["ChinaWeChatQuestionResults"] = result;
                this.grvQuestions.DataSource = result;
                this.grvQuestions.DataBind();

                
            }
            catch (Exception ex)
            {
                HidStatus.Value = "Failed! " +  ex.Message;
            }
        }

        protected void grvQuestions_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            grvQuestions.PageIndex = e.NewPageIndex;

            BindGrid();
        }

        private void BindGrid()
        {
            if (Session["ChinaWeChatQuestionResults"] != null)
            {
                if (Session["ChinaWeChatSortExpression"] == null)
                {
                    this.grvQuestions.DataSource = Session["ChinaWeChatQuestionResults"] as System.Data.DataTable;
                }
                else
                {
                    DataView view = new DataView(Session["ChinaWeChatQuestionResults"] as System.Data.DataTable);
                    view.Sort = Session["ChinaWeChatSortExpression"].ToString();
                    
                    grvQuestions.DataSource = view;
                }

                this.grvQuestions.DataBind();
            }
        }

        protected void grvQuestions_Sorting(object sender, GridViewSortEventArgs e)
        {
            string sortExpression = e.SortExpression;

            if (ViewState["SortOrder"] != null)
            {
                if (ViewState["SortOrder"].ToString() == sortExpression)
                {
                    if (ViewState["OrderDir"].ToString() == "DESC")
                    {
                        ViewState["OrderDir"] = "ASC";
                    }
                    else
                        if (ViewState["OrderDir"].ToString() == "ASC")
                        {
                            ViewState["OrderDir"] = "DESC";
                        }
                }
                ViewState["SortOrder"] = sortExpression;

            }
            else
            {
                ViewState["OrderDir"] = "ASC";
                ViewState["SortOrder"] = sortExpression;
            }

            Session["ChinaWeChatSortExpression"] = string.Format(" {0} {1}", sortExpression, ViewState["OrderDir"]);


            BindGrid();
        }

        protected void grvQuestions_RowCreated(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.Header)
            {
                // Call the GetSortColumnIndex helper method to determine
                // the index of the column being sorted.
                int sortColumnIndex = GetSortColumnIndex();

                if (sortColumnIndex != -1)
                {
                    // Call the AddSortImage helper method to add
                    // a sort direction image to the appropriate
                    // column header. 
                    AddSortImage(sortColumnIndex, e.Row);
                }
            }

        }

        // This is a helper method used to determine the index of the
        // column being sorted. If no column is being sorted, -1 is returned.
        int GetSortColumnIndex()
        {
            if (ViewState["SortOrder"] != null)
            {
                // Iterate through the Columns collection to determine the index
                // of the column being sorted.
                foreach (DataControlField field in grvQuestions.Columns)
                {
                    if (field.SortExpression == ViewState["SortOrder"].ToString())
                    {
                        return grvQuestions.Columns.IndexOf(field);
                    }
                }
            }
            
            return -1;
        }

        // This is a helper method used to add a sort direction
        // image to the header of the column being sorted.
        void AddSortImage(int columnIndex, GridViewRow headerRow)
        {
            if (grvQuestions.AllowSorting)
            {
                if (ViewState["OrderDir"] != null)
                {
                    // Create the sorting image based on the sort direction.
                    System.Web.UI.WebControls.Image sortImage = new System.Web.UI.WebControls.Image();
                    if (ViewState["OrderDir"].ToString() == "ASC")
                    {
                        sortImage.ImageUrl = "Images/Descending.png";
                        sortImage.AlternateText = "Ascending Order";
                    }
                    else
                    {
                        sortImage.ImageUrl = "Images/Ascending.png";
                        sortImage.AlternateText = "Descending Order";
                    }

                    // Add the image to the appropriate header cell.
                    headerRow.Cells[columnIndex].Controls.Add(sortImage);
                }
            }

        }

        protected void grvQuestions_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                switch (e.Row.Cells[11].Text)
                {
                    case "0":
                        e.Row.Cells[11].Text = "To Be Sent";
                        break;
                    case "1":
                        e.Row.Cells[11].Text = "Sent Successfully";
                        break;
                    case "2":
                        e.Row.Cells[11].Text = "Failed, To Be Sent Again";
                        break;
                    case "3":
                        e.Row.Cells[11].Text = "Duplcated Sending";
                        break;
                }
            }
        }

        protected void grvQuestions_DataBound(object sender, EventArgs e)
        {
            GridViewRow row = new GridViewRow(0, 0, DataControlRowType.Header, DataControlRowState.Normal);
            TableHeaderCell cell = new TableHeaderCell();
            cell.Text = "";
            cell.ColumnSpan = 1;
            row.Controls.Add(cell);

            cell = new TableHeaderCell();
            cell.ColumnSpan = 2;
            cell.Text = "Sales";
            row.Controls.Add(cell);

            cell = new TableHeaderCell();
            cell.ColumnSpan = 6;
            cell.Text = "HCP";
            row.Controls.Add(cell);

            cell = new TableHeaderCell();
            cell.Text = "";
            cell.ColumnSpan = 1;
            row.Controls.Add(cell);
            
            cell = new TableHeaderCell();
            cell.Text = "";
            cell.ColumnSpan = 1;
            row.Controls.Add(cell);
            cell = new TableHeaderCell();
            cell.Text = "";
            cell.ColumnSpan = 1;
            row.Controls.Add(cell);

            row.BackColor = ColorTranslator.FromHtml("#BCBEC0");
            grvQuestions.HeaderRow.Parent.Controls.AddAt(0, row);
        }

        protected void btnExport_Click(object sender, EventArgs e)
        {
            Response.Clear();
            Response.AddHeader("content-disposition", "attachment;filename=ChinaWechatQuestions.xls");
            Response.Charset = "gb2312";
            Response.ContentType = "application/vnd.xls";
            System.IO.StringWriter stringWrite = new System.IO.StringWriter();
            System.Web.UI.HtmlTextWriter htmlWrite = new HtmlTextWriter(stringWrite);

            grvQuestions.AllowPaging = false;
            grvQuestions.AllowSorting = false;
            BindGrid();
            grvQuestions.RenderControl(htmlWrite);

            Response.Write(stringWrite.ToString());
            Response.End();

            grvQuestions.AllowPaging = true;
            grvQuestions.AllowSorting = true;
            BindGrid();
        }

        public override void VerifyRenderingInServerForm(Control control)
        {



        }
    }
}
