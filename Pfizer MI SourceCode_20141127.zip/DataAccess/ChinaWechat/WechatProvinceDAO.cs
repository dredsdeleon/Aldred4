﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using log4net;
using ChinaHcp.DataAccess.HcpSearch;
using System.Data.SqlClient;

namespace ChinaHcp.DataAccess.ChinaWechat
{
    public class WechatProvinceDAO:DaoBase
    {
        private static readonly ILog logger = LogManager.GetLogger(typeof(Search));

        public WechatProvinceDAO()
            : base()
        {}

        public DataTable GetWechatProvince()
        {
            try
            {
                SqlConnection conn = GetConnection();
                //DataSet result= SqlHelper.ExecuteDataset(conn, CommandType.Text, "SELECT ProvinceID,NameEN,NameCN FROM province ORDER BY NameCN collate Chinese_PRC_CI_AS");

                DataSet result = SqlHelper.ExecuteDataset(conn, CommandType.Text, "SELECT A.NameCN,B.Chinese AS NameCHS FROM Province A INNER JOIN ProvinceMapping B ON A.ProvinceID=B.ProvinceMappingID WHERE A.NameCN LIKE '%市'  ORDER BY A.NameCN collate Chinese_PRC_CI_AS");
                DataSet result1 = SqlHelper.ExecuteDataset(conn, CommandType.Text, "SELECT A.NameCN,B.Chinese AS NameCHS FROM Province A INNER JOIN ProvinceMapping B ON A.ProvinceID=B.ProvinceMappingID WHERE A.NameCN NOT LIKE '%市'  ORDER BY A.NameCN collate Chinese_PRC_CI_AS");

                result.Merge(result1, false, MissingSchemaAction.Ignore);
                conn.Close();
                conn.Dispose();
                return result.Tables[0];
            }
            catch (Exception ex)
            {
                throw ex;
                //logger.Debug("ChinaWebChat:" + ex.Message);
            }
            return null;
        }
    }
}
