﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ChinaHcp.DataAccess.Linq;
using System.Data;
using ChinaHcp.DataAccess.ChinaWechat.Model;

namespace ChinaHcp.DataAccess.ChinaWechat
{
    public class WechatAccess
    {
        private readonly ChinaHcpDataContext dc;

        public WechatAccess()
        {
            dc = new ChinaHcpDataContext();
        }

        public DataTable GetMITradeProduct()
        {
            var bu = new WechatMIQuestionDAO();
            return bu.GetWechatMITradeProduct();
        }

        public DataTable GetSpecialty()
        {
            var bu = new WechatSpecialtyDAO();
            return bu.GetWechatSpecialty();
        }

        public DataTable GetProvince()
        {
            var bu = new WechatProvinceDAO();
            return bu.GetWechatProvince();
        }

        public string GetWechatInfo(string fullName)
        {
            var bu = new WechatInfoDAO();
            return DataTableConvertJson.DataTable2Json(bu.GetWechatInfo(fullName));
        }

        public DataTable GetWechatInfoById(string id)
        {
            var bu = new WechatInfoDAO();
            return bu.GetWechatInfoById(id);
        }

        public int SaveWechatInfo(WechatMIQuestion info)
        {
            var bu = new WechatInfoDAO();
            return bu.SaveWechatInfo(info);
        }

        public string SearchWechatInfo(string search)
        {
            var bu = new WechatInfoDAO();
            return DataTableConvertJson.DataTable2Json(bu.SearchWechatInfo(search));
        }
    }
}
