﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using log4net;
using ChinaHcp.DataAccess.HcpSearch;
using System.Data;
using System.Data.SqlClient;
using ChinaHcp.DataAccess.ChinaWechat.Model;

namespace ChinaHcp.DataAccess.ChinaWechat
{
    public class WechatInfoDAO : DaoBase
    {
        private static readonly ILog logger = LogManager.GetLogger(typeof(Search));

        public WechatInfoDAO()
            : base()
        { }

        public DataTable GetWechatInfo(string fullName)
        {
            try
            {
                SqlConnection conn = GetConnection();
                SqlParameter[] parameters = new SqlParameter[1];
                parameters[0] = new SqlParameter("@fullName", SqlDbType.NVarChar);
                parameters[0].Value = fullName;
                DataSet result = SqlHelper.ExecuteDataset(conn, CommandType.Text, "SELECT * FROM view_ChinaWechatGetHcpInfoByFullName WHERE FullName = @fullName", parameters);
                conn.Close();
                conn.Dispose();
                return result.Tables[0];
            }
            catch (Exception ex)
            {
                throw ex;
                //logger.Debug("ChinaWebChat:" + ex.Message);
            }
            return null;
        }

        public DataTable GetWechatInfoById(string id)
        {
            try
            {
                SqlConnection conn = GetConnection();
                SqlParameter[] parameters = new SqlParameter[1];
                parameters[0] = new SqlParameter("@WechatMIQuestionID", SqlDbType.UniqueIdentifier);
                parameters[0].Value = new Guid(id);
                DataSet result = SqlHelper.ExecuteDataset(conn, CommandType.Text, "SELECT * FROM WechatMIQUestion WHERE WechatMIQuestionID = @WechatMIQuestionID", parameters);
                conn.Close();
                conn.Dispose();
                return result.Tables[0];
            }
            catch (Exception ex)
            {
                throw ex;
                //logger.Debug("ChinaWebChat:" + ex.Message);
            }
            return null;
        }

        public int SaveWechatInfo(WechatMIQuestion info)
        {
            try
            {
                SqlConnection conn = GetConnection();
                SqlParameter[] parameters = new SqlParameter[22];
                parameters[0] = new SqlParameter("@NTID", SqlDbType.NVarChar);
                parameters[0].Value = info.NTID;
                parameters[1] = new SqlParameter("@Email", SqlDbType.NVarChar);
                parameters[1].Value = String.Empty;
                parameters[2] = new SqlParameter("@Phone", SqlDbType.NVarChar);
                parameters[2].Value = String.Empty;
                parameters[3] = new SqlParameter("@Department", SqlDbType.NVarChar);
                parameters[3].Value = String.Empty;
                parameters[4] = new SqlParameter("@FullName", SqlDbType.NVarChar);
                parameters[4].Value = String.Empty;


                parameters[5] = new SqlParameter("@HcpID", SqlDbType.UniqueIdentifier);
                if (info.HcpID == string.Empty || info.HcpID == "")
                    parameters[5].Value = System.DBNull.Value;
                else
                    parameters[5].Value = new Guid(info.HcpID);

                parameters[6] = new SqlParameter("@HcpFullName", SqlDbType.NVarChar);
                parameters[6].Value = info.HcpFullName;
                parameters[7] = new SqlParameter("@HcpHospital", SqlDbType.NVarChar);
                parameters[7].Value = info.HcpHospital;
                parameters[8] = new SqlParameter("@HcpDepartment", SqlDbType.NVarChar);
                parameters[8].Value = info.HcpDepartment;
                parameters[9] = new SqlParameter("@HcpDeptCode", SqlDbType.NVarChar);
                parameters[9].Value = info.HcpDeptCode;
                parameters[10] = new SqlParameter("@HcpProvince", SqlDbType.NVarChar);
                parameters[10].Value = info.HcpProvince;
                parameters[11] = new SqlParameter("@HcpProvinceCHS", SqlDbType.NVarChar);
                parameters[11].Value = info.HcpProvinceCHS;

                parameters[12] = new SqlParameter("@HcpCity", SqlDbType.NVarChar);
                parameters[12].Value = info.HcpCity;
                parameters[13] = new SqlParameter("@HcpPhone", SqlDbType.NVarChar);
                parameters[13].Value = info.HcpPhone;
                parameters[14] = new SqlParameter("@HcpEmail", SqlDbType.NVarChar);
                parameters[14].Value = info.HcpEmail;
                parameters[15] = new SqlParameter("@WechatMITradeProductID", SqlDbType.UniqueIdentifier);

                if (info.WechatMIQuestionID == string.Empty || info.WechatMIQuestionID == "")
                    parameters[15].Value = System.DBNull.Value;
                else
                    parameters[15].Value = new Guid(info.WechatMIQuestionID);

                parameters[16] = new SqlParameter("@ProductCode", SqlDbType.NVarChar);
                parameters[16].Value = info.ProductCode;
                parameters[17] = new SqlParameter("@ProductNameZH", SqlDbType.NVarChar);
                parameters[17].Value = info.ProductNameZH;

                parameters[18] = new SqlParameter("@Question", SqlDbType.NVarChar);
                parameters[18].Value = info.Question;
                parameters[19] = new SqlParameter("@SendStatus", SqlDbType.Int);
                parameters[19].Value = 0;
                parameters[20] = new SqlParameter("@ModifiedBy", SqlDbType.NVarChar);
                parameters[20].Value = info.ModifiedBy;
                parameters[21] = new SqlParameter("@CreatedBy", SqlDbType.NVarChar);
                parameters[21].Value = info.CreatedBy;


                //string cmdText = "INSERT INTO WechatMIQUestion(NTID,Email,HcpID,HcpFullName,HcpHospital,HcpDepartment,HcpDeptCode,HcpProvince,HcpProvinceCHS,HcpCity," +
                //        "HcpPhone,HcpEmail,WechatMITradeProductID,ProductCode,ProductNameZH,Question,ModifiedBy,CreatedBy,SendStatus) Values" +
                //        "(@NTID,@Email,@HcpID,@HcpFullName,@HcpHospital,@HcpDepartment,@HcpDeptCode,@HcpProvince,@HcpProvinceCHS,@HcpCity," +
                //        "@HcpPhone,@HcpEmail,@ProdcutID,@ProductCode,@ProductNameZH,@Question,@ModifiedBy,@CreatedBy,@SendStatus)";
                //int result = SqlHelper.ExecuteNonQuery(conn, CommandType.Text, cmdText, parameters);

                string cmdText = "SP_ChinaWechatAddQuestion";
                int result = SqlHelper.ExecuteNonQuery(conn,CommandType.StoredProcedure,cmdText, parameters);

                conn.Close();
                conn.Dispose();
                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            //return 1;
        }

        public DataTable SearchWechatInfo(string search)
        {
            try
            {
                SqlConnection conn = GetConnection();

                DataSet result = SqlHelper.ExecuteDataset(conn, CommandType.Text, "SELECT *,CONVERT(varchar,CreatedOn,101) AS CreatedOnDate FROM WechatMIQUestion WHERE " + search + " ORDER BY CreatedOn DESC");
                conn.Close();
                conn.Dispose();
                return result.Tables[0];
            }
            catch (Exception ex)
            {
                throw ex;
                //logger.Debug("ChinaWebChat:" + ex.Message);
            }
            return null;
        }
    }
}
