﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using log4net;
using ChinaHcp.DataAccess.HcpSearch;
using System.Data.SqlClient;

namespace ChinaHcp.DataAccess.ChinaWechat
{
    public class WechatMIQuestionDAO :DaoBase
    {
        private static readonly ILog logger = LogManager.GetLogger(typeof(Search));

        public WechatMIQuestionDAO() : base()
        {}

        public DataTable GetWechatMITradeProduct()
        {
            try
            {
                SqlConnection conn = GetConnection();
                DataSet result = SqlHelper.ExecuteDataset(conn, CommandType.Text, "SELECT WechatMITradeProductID,TradeNameEN,TradeNameZH, CAST(WechatMITradeProductID AS VARCHAR(36)) + TradeNameEN AS ProductID FROM WechatMITradeProduct WHERE IsActive = 1 ORDER BY TradeNameZH collate Chinese_PRC_CI_AS");
                conn.Close();
                conn.Dispose();
                return result.Tables[0];
            }
            catch (Exception ex)
            {
                throw ex;
                //logger.Debug("ChinaWebChat:" + ex.Message);
            }
            return null;
        }
    }
}
