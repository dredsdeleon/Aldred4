﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ChinaHcp.DataAccess.ChinaWechat.Model
{
    public class WechatMIQuestion
    {
        public string WechatMIQuestionID { get; set; }
        public int AutoNo { get; set; }
        public string QuestionUID { get; set; }
        public string NTID { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
        public string Department { get; set; }
        public string FullName { get; set; }
        public string HcpID { get; set; }
        public string HcpFullName { get; set; }
        public string HcpHospital { get; set; }
        public string HcpDeptCode { get; set; }
        public string HcpDepartment { get; set; }
        public string HcpProvince { get; set; }
        public string HcpProvinceCHS { get; set; }
        public string HcpCity { get; set; }
        public string HcpPhone { get;set;}
        public string HcpEmail { get; set; }
        public string WechatMITradeProductID { get; set; }
        public string ProductCode {get;set;}
        public string ProductNameZH { get; set; }
        public string Question { get; set; }
        public int SendStauts { get; set; }
        public string CreatedBy { get; set; }
        public string ModifiedBy { get; set; }
    }
}
