﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Configuration;
using ChinaHcp.DataAccess.HcpSearch;
using log4net;

namespace ChinaHcp.DataAccess.ChinaWechat
{
    public class DaoBase
    {
        private static readonly ILog logger = LogManager.GetLogger(typeof(Search));
        //public static string DatabaseConnString = Properties.Settings.Default.FSRValuationRequestsConnectionString;
        String DatabaseConnString = ConfigurationManager.ConnectionStrings["HCP"].ToString();
        public DaoBase()
        {
        }
        public SqlConnection GetConnection()
        {
            try
            {
                SqlConnection conn = new SqlConnection(DatabaseConnString);
                return conn;
            }
            catch (Exception ex)
            {
                logger.Debug("ChinaWebChat:" + ex.Message);
            }
            return null;
        }
    }
}
