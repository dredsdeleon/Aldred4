﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using log4net;
using System.Data;
using ChinaHcp.DataAccess.SearchEngine;
using System.Data.SqlClient;

namespace ChinaHcp.DataAccess.ChinaWechat
{
    public class WechatSpecialtyDAO:DaoBase
    {
        private static readonly ILog logger = LogManager.GetLogger(typeof(Search));

        public WechatSpecialtyDAO()
            : base()
        {}

        public DataTable GetWechatSpecialty()
        {
            try
            {
                SqlConnection conn = GetConnection();
                //DataSet result = SqlHelper.ExecuteDataset(conn, CommandType.Text, "SELECT A.SpecialtyID, A.NameZH, B.SpecialtyCode AS NameEN FROM Specialty A INNER JOIN SpecialtyMapping B ON A.SpecialtyID=B.SpecialtyMappingID  ORDER BY A.NameZH collate Chinese_PRC_CI_AS");
                DataSet result = SqlHelper.ExecuteDataset(conn, CommandType.Text, "SELECT A.SpecialtyID, A.NameZH, B.SpecialtyCode AS NameEN FROM Specialty A INNER JOIN SpecialtyMapping B ON A.SpecialtyID=B.SpecialtyMappingID  WHERE  A.NameZH!='其他' ORDER BY A.NameZH collate Chinese_PRC_CI_AS");
                DataSet result1 = SqlHelper.ExecuteDataset(conn, CommandType.Text, "SELECT A.SpecialtyID, A.NameZH, B.SpecialtyCode AS NameEN FROM Specialty A INNER JOIN SpecialtyMapping B ON A.SpecialtyID=B.SpecialtyMappingID  WHERE  A.NameZH ='其他' ORDER BY A.NameZH collate Chinese_PRC_CI_AS");
                result.Merge(result1, false, MissingSchemaAction.Ignore);
                conn.Close();
                conn.Dispose();
                return result.Tables[0];
            }
            catch (Exception ex)
            {
                throw ex;
                //logger.Debug("ChinaWebChat:" + ex.Message);
            }
            return null;
        }
    }
}
