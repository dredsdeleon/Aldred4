﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ChinaHcp.DataAccess.ChinaWechat;
using ChinaHcp.DataAccess.ChinaWechat.Model;
using System.Security;
using System.Security.Cryptography;
using System.Text;

namespace ChinaHcp.Web.Portal.ChinaWechat
{
    public partial class MISearchResult : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
           string currentBrowser = Request.UserAgent.ToString().ToLower();

           if (currentBrowser.IndexOf("micromessenger") <= 0)
           {
               Response.Redirect("ChinaWechatError.htm?Error=" + GetLocalResourceObject("errMsg").ToString() + GetLocalResourceObject("errBrowser").ToString());
               //Response.End();
           }
           
            //restrict forward
            if (Request.QueryString["from"] != null && !string.IsNullOrEmpty(Request.QueryString["from"].ToString()))
            {
                Response.Redirect("ChinaWechatError.htm?Error=" + GetLocalResourceObject("errMsg").ToString() + GetLocalResourceObject("errForward").ToString());
                //Response.End();
            }            
            if (!Page.IsPostBack)
            {

                if (Request.QueryString["NTID"] != null && !string.IsNullOrEmpty(Request.QueryString["NTID"].ToString()))
                {
                    hidNTID.Value = Request.QueryString["NTID"].ToString();
                }
                if (Request.QueryString["email"] != null && !string.IsNullOrEmpty(Request.QueryString["email"].ToString()))
                {
                    hidEmail.Value = Request.QueryString["email"].ToString();
                }
                if (Request.QueryString["openid"] != null && !string.IsNullOrEmpty(Request.QueryString["openid"].ToString()))
                {
                    hidOpenID.Value = Request.QueryString["openid"].ToString();
                }
                if (Request.QueryString["code"] != null && !string.IsNullOrEmpty(Request.QueryString["code"].ToString()))
                {
                    hidCode.Value = Request.QueryString["code"].ToString();
                }
            }
            if (string.IsNullOrEmpty(hidNTID.Value) || string.IsNullOrEmpty(hidOpenID.Value) || !checkPara(hidNTID.Value, hidOpenID.Value, hidEmail.Value, hidCode.Value))
            {
                //HidStatus.Value = GetLocalResourceObject("errMsg").ToString() + GetLocalResourceObject("errPara").ToString();
                Response.Redirect("ChinaWechatError.htm?Error=" + GetLocalResourceObject("errMsg").ToString() + GetLocalResourceObject("errPara").ToString());
                //Response.End();

            }

        }
        private bool checkPara(string NTID, string openid, string email, string code)
        {
            MD5CryptoServiceProvider md5 = new MD5CryptoServiceProvider();
            string strInput = openid + NTID + email + "imslscl";


            byte[] byteInput = System.Text.Encoding.Default.GetBytes(strInput);
            byte[] byteOutput = md5.ComputeHash(byteInput);
            string strOutput = "";
            for (int i = 0; i < byteOutput.Length; i++)
            {
                strOutput += byteOutput[i].ToString("x2");
            }
            //HidStatus.Value = strOutput;
            if (strOutput == code)
                return true;
            else
                return false;

        }

    }
}
