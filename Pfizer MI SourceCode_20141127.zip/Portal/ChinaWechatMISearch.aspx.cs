﻿using System;
using System.Web;
using System.Linq;
using System.Text;
using System.Web.UI;
using System.Security;
using System.Web.UI.WebControls;
using System.Collections.Generic;
using System.Security.Cryptography;

using ChinaHcp.DataAccess.ChinaWechat;
using ChinaHcp.DataAccess.ChinaWechat.Model;

namespace ChinaHcp.Web.Portal.ChinaWechat
{
    public partial class MISearch : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            CheckBrowser();
            ProhibitForward();
            CheckCode();

            if (IsPostBack)
            {
                return;
            }

            BindDropDownList();
        }

        private void CheckBrowser()
        {
            
            string currentBrowser = Request.UserAgent.ToString().ToLower();

            if (currentBrowser.IndexOf("micromessenger")>0)
            {
                return;
            }

            string errorMessage = GetLocalResourceObject("errMsg").ToString();
            string browserError = GetLocalResourceObject("errBrowser").ToString();

            string redirectUrl = string.Format("ChinaWechatError.htm?Error={0}{1}", errorMessage, browserError);
            Response.Redirect(redirectUrl, true);
        }

        private void ProhibitForward()
        {
            if (Request["from"] == null)
            {
                return;
            }

            string errorMessage = GetLocalResourceObject("errMsg").ToString();
            string forwardError = GetLocalResourceObject("errForward").ToString();

            string redirectUrl = string.Format("ChinaWechatError.htm?Error={0}{1}", errorMessage, forwardError);
            Response.Redirect(redirectUrl, true);
        }

        private void CheckCode()
        {
            string SECRET_KEY = "imslscl";

            string openId = Request["openid"];
            string ntid = Request["ntid"];
            string email = Request["email"];
            string code = Request["code"];

            string source = openId + ntid + email + SECRET_KEY;
            string hashCode = GetHashCode(source);

            if (hashCode == code)
            {
                return;
            }

            string errorMessage = GetLocalResourceObject("errMsg").ToString();
            string parameterError = GetLocalResourceObject("errPara").ToString();
            string redirectUrl = string.Format("ChinaWechatError.htm?Error={0}{1}", errorMessage, parameterError);
            Response.Redirect(redirectUrl, true);
        }

        private string GetHashCode(string input)
        {
            MD5CryptoServiceProvider md5CryptProvider = new MD5CryptoServiceProvider();

            byte[] inputByte = Encoding.Default.GetBytes(input);
            byte[] outputByte = md5CryptProvider.ComputeHash(inputByte);

            string output = "";
            for (int i = 0; i < outputByte.Length; i++)
            {
                output += outputByte[i].ToString("x2");
            }

            return output;
        }

        private void BindDropDownList()
        {
            //1. status dropdownlist
            ddlStatus.Items.Add(new ListItem { Value = "-1", Text = GetLocalResourceObject("Status_All").ToString() });
            ddlStatus.Items.Add(new ListItem { Value = "0", Text = GetLocalResourceObject("Status_Submit").ToString() });
            ddlStatus.Items.Add(new ListItem { Value = "1", Text = GetLocalResourceObject("Status_Send").ToString() });
            ddlStatus.Items.Add(new ListItem { Value = "2", Text = GetLocalResourceObject("Status_Voided").ToString() });

            //2. range dropdownlist
            //range=='$' mains this month.
            //ddlRange.Items.Add(new ListItem { Value = "$", Text = GetLocalResourceObject("Range_ThisMonth").ToString() });

            //range=='x' mains last x months. 
            ddlRange.Items.Add(new ListItem { Value = "1", Text = GetLocalResourceObject("Range_LastOneMonth").ToString() });
            ddlRange.Items.Add(new ListItem { Value = "2", Text = GetLocalResourceObject("Range_LastTwoMonth").ToString() });
            ddlRange.Items.Add(new ListItem { Value = "6", Text = GetLocalResourceObject("Range_LastSixMonth").ToString() });

            //range=='*' mains six months ago.
            ddlRange.Items.Add(new ListItem { Value = "*", Text = GetLocalResourceObject("Range_SixMonthAgo").ToString() });

        }
    }
}
