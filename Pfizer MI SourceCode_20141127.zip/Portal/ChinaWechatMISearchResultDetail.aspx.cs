﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ChinaHcp.DataAccess.ChinaWechat;
using ChinaHcp.DataAccess.ChinaWechat.Model;

namespace ChinaHcp.Web.Portal.ChinaWechat
{
    public partial class MISearchResultDetail : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {


            string currentBrowser = Request.UserAgent.ToString().ToLower();

            if (currentBrowser.IndexOf("micromessenger") <= 0)
            {
                Response.Redirect("ChinaWechatError.htm?Error=" + GetLocalResourceObject("errMsg").ToString() + GetLocalResourceObject("errBrowser").ToString());
                //Response.End();
            }
           

            //restrict forward
            if (Request.QueryString["from"] != null && !string.IsNullOrEmpty(Request.QueryString["from"].ToString()))
            {
                //Response.Write(Request.QueryString["from"]);
                Response.Redirect("ChinaWechatError.htm?Error=" + GetLocalResourceObject("errMsg").ToString() + GetLocalResourceObject("errForward").ToString());
                //Response.End();
            }



            if (!Page.IsPostBack)
            {
                ShowWechatInfo();
            }
        }

        private void ShowWechatInfo()
        {
            string id = Request.QueryString["id"];

            if (!string.IsNullOrEmpty(id))
            {
                var da = new ChinaHcp.DataAccess.ChinaWechat.WechatAccess();
                
                try
                {
                    var result = da.GetWechatInfoById(id);
                    

                    if (result != null && result.Rows.Count > 0)
                    {
                        var row = result.Rows[0];
                        txtNo.Text = row["QuestionUID"].ToString();
                        this.txtFullName.Text = row["HcpFullName"].ToString();
                        this.txtHospital.Text = row["HcpHospital"].ToString();
                        this.txtDepartment.Text = row["HcpDepartment"].ToString();

                        if (row["HcpProvince"].ToString() == row["HcpCity"].ToString())
                        {
                            this.txtProvince.Text = row["HcpProvince"].ToString();
                        }
                        else
                        {
                            this.txtProvince.Text = row["HcpProvince"].ToString() + "/" + row["HcpCity"].ToString();
                        }
                        
                        this.txtEmail.Text = row["HcpEmail"].ToString();
                        this.txtPhone.Text = row["HcpPhone"].ToString();
                        this.txtProduct.Text = row["ProductNameZH"].ToString();
                        this.txtQuestion.Text = row["Question"].ToString();
                        this.txtCreatedOn.Text = row["CreatedOn"].ToString();

                        
                        switch (row["SendStatus"].ToString())
                        {
                            case "0":
                                this.txtStatus.Text = GetLocalResourceObject("Status0").ToString();
                                break;
                            case "1":
                                this.txtStatus.Text =GetLocalResourceObject("Status13").ToString();
                                break;
                            case "3":
                                this.txtStatus.Text = GetLocalResourceObject("Status13").ToString();
                                break;
                            case "2":
                                this.txtStatus.Text = GetLocalResourceObject("Status2").ToString();
                                break;
                        }
                        
                    }
                }
                catch (Exception ex)
                {
                    HidStatus.Value = GetLocalResourceObject("Failed").ToString() + ex.Message;
                    ChinaWechatUtility.LogMessage(ex.Message, String.Empty);
              
                }
            }
        }
    }
}
