﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.IO;

namespace ChinaHcp.Web.Portal.ChinaWechat
{
    public class ChinaWechatUtility
    {
        public static void LogMessage(string msg,string ntid) {
            try
            {
                //write log
                if (ConfigurationManager.AppSettings["ChinaWechatLog"] == "YES")
                {
                    //get file path
                    string path = ConfigurationManager.AppSettings["ChinaWechatLogFile"].ToString();

                    if (!File.Exists(path))
                    {
                        //file not exists
                        StreamWriter sw = File.CreateText(path);
                        sw.WriteLine(DateTime.Now.ToLongDateString() + ' ' + DateTime.Now.ToLongTimeString());
                        sw.WriteLine("NTID: " + ntid);
                        sw.WriteLine("Message: " + msg);
                        sw.WriteLine();
                        sw.Close();
                    }
                    else
                    {
                        StreamWriter sw = File.AppendText(path);
                        sw.WriteLine(DateTime.Now.ToLongDateString() + ' ' + DateTime.Now.ToLongTimeString());
                        sw.WriteLine("NTID: " + ntid);
                        sw.WriteLine("Message: " + msg);
                        sw.WriteLine();
                        sw.Close();
                    }
                }
            }
            catch{}
        
        }
    }
}
