﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.SessionState;

namespace ChinaHcp.Web.Portal.Services
{
    /// <summary>
    /// Summary description for $codebehindclassname$
    /// </summary>
    public class ChinaWeChat : IHttpHandler, IRequiresSessionState
    {

        public void ProcessRequest(HttpContext context)
        {
            context.Response.ContentType = "json";

            string action = context.Request.QueryString["action"];
            switch (action.ToLower())
            {
                case "search":
                    GetSearchResult(context);
                    break;
                
                default:
                    break;
            }           
        }

        //private string SQLSafe(string str)
        //{
        //    if (string.IsNullOrEmpty(str))
        //    {
        //        return string.Empty;
        //    }
        //    return str.Replace("'", string.Empty);
        //}

        protected void GetSearchResult(HttpContext context)
        {
            string startdate = context.Request.Form["startdate"];
            string enddate = context.Request.Form["enddate"];
            string keyword = context.Server.UrlDecode(context.Request.Form["keyword"]);
            string status =context.Request.Form["status"];
            string openid = context.Request.Form["openid"];
            string NTID = context.Request.Form["NTID"];

            if (string.IsNullOrEmpty(status))
            {
                status = "-1";
            }


            //filter by question owner and question status
            string search =string.Empty;
            
            
            if (status == "-1")
            {
                search = string.Format(" (CreatedBy = '{0}' AND NTID='{1}') ", openid, NTID);
            }
            else if (status == "1")
            {
                search = string.Format(" (CreatedBy = '{0}' AND NTID='{1}' AND (SendStatus={2} OR SendStatus = 3))", openid, NTID, status);
            }
            else
            {
                search = string.Format(" (CreatedBy = '{0}' AND NTID='{1}' AND SendStatus={2}) ", openid, NTID, status);
            
            }
                      
            //fliter by date
            

            if (!string.IsNullOrEmpty(startdate))
            {
                if (!string.IsNullOrEmpty(search))
                {
                    search += " AND ";
                }
                startdate += " 00:00:000";
                search += string.Format(" {0} >= '{1}' ", "CreatedOn", startdate);
            }


            if (!string.IsNullOrEmpty(enddate))
            {
                if (!string.IsNullOrEmpty(search))
                {
                    search += " AND ";
                }
                enddate += " 23:59:59";
                search += string.Format(" {0} <= '{1}' ", "CreatedOn", enddate);
            }

            
            //as all parameter are same key word, so just need to check fullname
            string searchSql = string.Empty;
            if (!string.IsNullOrEmpty(keyword))
            {
                keyword = keyword.Replace("'", "''");

                searchSql += string.Format(" {0} LIKE '%{1}%' ", "HcpFullName", keyword);
                searchSql += " OR ";
                searchSql += string.Format(" {0} LIKE '%{1}%' ", "HcpHospital", keyword);
                searchSql += " OR ";
                searchSql += string.Format(" {0} LIKE '%{1}%' ", "HcpProvince", keyword);
                searchSql += " OR ";
                searchSql += string.Format(" {0} LIKE '%{1}%' ", "HcpDepartment", keyword);
                searchSql += " OR ";
                searchSql += string.Format(" {0} LIKE '%{1}%' ", "HcpCity", keyword);
                searchSql += " OR ";
                //searchSql += string.Format(" {0} LIKE '%{1}%' ", "ProductCode", keyword);
                //searchSql += " OR ";
                searchSql += string.Format(" {0} LIKE '%{1}%' ", "ProductNameZH", keyword);
                searchSql += " OR ";
                searchSql += string.Format(" {0} LIKE '%{1}%' ", "Question", keyword);
            
            }


            if (!string.IsNullOrEmpty(searchSql))
            {
                search = string.Format(" ({0}) AND ({1})", search, searchSql);
            }
                 
            
            var da = new ChinaHcp.DataAccess.ChinaWechat.WechatAccess();
            string result = string.Empty;
            try
            {
                result = da.SearchWechatInfo(search);
                if (string.IsNullOrEmpty(result))
                {
                    result = string.Empty;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            
            context.Response.Clear();
            context.Response.ContentType = "text/json";
            context.Response.Write(result);
            context.Response.End();
             
        }


        public bool IsReusable
        {
            get
            {
                return false;
            }
        }

        
    }
}
