﻿(function () {
    document.addEventListener('WeixinJSBridgeReady', function onBridgeReady() {
        WeixinJSBridge.invoke('hideOptionMenu');
    });
} ());




$(document).ready(function () {


});

function hideColumnToggle() {
    //hide column toggle buttons
    $('.ui-table-columntoggle-btn').hide();
}

function getQueryStringByName(name) {

    var result = location.search.match(new RegExp("[\?\&]" + name + "=([^\&]+)", "i"));

    if (result == null || result.length < 1) {

        return "";

    }

    return result[1];

}
function goBack() {
    history.back();
}

function doSubmit() {
    hideColumnToggle();
    //document.forms[0].submit();
    var keyword = (getQueryStringByName("keyword"));
    var startdate = getQueryStringByName("startdate");
    var enddate = getQueryStringByName("enddate");
    var status = getQueryStringByName("status");
    var openid = getQueryStringByName("openid");
    var NTID = getQueryStringByName("NTID");


    $.ajax({
        type: "POST",
        url: "ChinaWeChat/ChinaWeChat.ashx?action=search",
        data: { 'openid': openid, 'NTID': NTID, 'startdate': startdate, 'enddate': enddate, 'keyword': keyword, 'status': status },
        dataType: "json",
        success: function (response) {

            if (response != null) {
                $.each(response.Table, function (i, item) {
                    var date = item.CreatedOnDate,
                        dateHtml = getDateHtml(date);

                    var tr = $('<tr></tr>');
					
                    $('<td>' 
						+'<span>'+item.HcpFullName+'</span>'
						+dateHtml
						+ '</td>'
					).appendTo(tr);
					
					$('<td>' 
						+'<span>'
							+ (item.Question.length <= 42?item.Question:item.Question.slice(0, 42)+'...') 
						+'</span>'
					+ '</td>'
					).appendTo(tr).delegate('>span','click',function(e){
						var span=$(this);
						
						e.stopPropagation();							
						location.href = 'ChinaWechatMISearchResultDetail.aspx?id=' + item.WechatMIQuestionID;
					});
						
					/*	
						$('<td>' + item.HcpHospital + '</td>').appendTo($(tr));
						$('<td>' + item.ProductNameZH + '</td>').appendTo($(tr));
						if (item.SendStatus == '0')
							$('<td>' + $("#hidStatus0").val() + '</td>').appendTo($(tr));
						if (item.SendStatus == '2')
							$('<td>' + $("#hidStatus2").val() + '</td>').appendTo($(tr));
						if (item.SendStatus == '1' || item.SendStatus == '3')
							$('<td>' + $("#hidStatus1").val() + '</td>').appendTo($(tr));
					*/
                    tr.appendTo('#tableBody');
                });

                $('#tblSearch').table('refresh');
                hideColumnToggle();
            } else {

            }
        }
    });

    function getDateHtml(date) {
        var regexp = /^(\d{2}\/\d{2})\/(\d{4})$/,
            match = regexp.exec(date);

        if (match == null) {
            return '';
        }

        var monthDay = match[1],
            year = match[2];

        return '<span>' + monthDay + '</span><span>' + year + '</span>';
    }
}