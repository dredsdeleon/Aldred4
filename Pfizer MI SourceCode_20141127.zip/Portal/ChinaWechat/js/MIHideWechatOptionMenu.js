﻿(function hideWechatOptionMenu() {
    document.addEventListener('WeixinJSBridgeReady', function onBridgeReady() {
        WeixinJSBridge.invoke('hideOptionMenu');
    });
} ());