﻿$(function () {
    var WARNING_ITEM_NAME = '艾乐妥',
        WARNING_MESSAGE = '咨询艾乐妥相关问题，根据公司间协议，请联系施贵宝的医学信息团队获得相关信息\n- medinfo.china@bms.com\n- 800 820 8790';

    //set title multilingual
    $('title').html($('#pageHeader').text());

    reportSuccessAfterSubmit();

    //temporarily delete 2014.10.30 10.00
    //$('#txtFullName').blur(function () {
    //    var fullNameValue = $(this).val().trim(),
    //        isEmpty = fullNameValue === '';

    //    if (isEmpty) {
    //        return;
    //    }

    //    showHospitalListForSelection(fullNameValue);
    //});

    //when textbox blur: validate and change style
    $('#txtFullName,#txtHospital,#txtCity,#txtEmail,#textDesc').blur(function () {
        var textbox = $(this);

        textbox.val() === ''
            ? textbox.addClass('requireUserInput')
            : textbox.removeClass('requireUserInput');
    });

    //when dropdownlist change: validate and change style
    $('#dllDepartment,#dllProvince').change(function () {
        var select = $(this),
            isDefaultValue = select.val() === '';

        //dropdown list: add class to its parent div, because jquery mobile would wrap it.
        isDefaultValue
            ? select.parent('div').addClass('requireUserInput')
            : select.parent('div').removeClass('requireUserInput');
    });

    $('#dllProduct').change(function () {
        var select = $(this),
            isSelectWarningItem = select.find('>option:selected').text().trim() === WARNING_ITEM_NAME;

        if (!isSelectWarningItem) {
            $('#textDesc,#buttonPanel').show();
            $('#divQuestionDescription').parent('tr').show();
            return;
        }

        $('#textDesc,#buttonPanel').hide();
        $('#divQuestionDescription').parent('tr').hide();
		
		//fixed jquery mobile bug on ipad, can't show alert and transparent background lock the screen.
		setTimeout(function(){
			alert(WARNING_MESSAGE);
		},0);
    });

    $('#chkRelated').click(function () {
        $('#divProd').toggle();
        $('#hidProdRelated').val($('#chkRelated').is(':checked') ? 'Yes' : 'No');

        //trigger change event: show submit button and enable textarea
        $('#dllProduct').val('').change().prev('span').text($('#dllProduct').find('option:selected').text());
    });

    //submit button click: validate page
    $('#btnSubmit').click(function () {

        //filter all html label in textbox
        $('#txtFullName,#txtHospital,#txtCity,#txtEmail,#txtPhone,#textDesc').each(function () {
            var $textbox = $(this);

            $textbox.val(filterHtmlLabel($textbox.val()));
        });

        var errorMessage = getValidateErrorMessage(),
            hasError = errorMessage !== '',
            isSelectWarningItem = $('#dllProduct').find('>option:selected').text().trim() === WARNING_ITEM_NAME;

        if (isSelectWarningItem) {
            alert(WARNING_MESSAGE);
            return false;
        }

        if (hasError) {
            showUserRequireInputStyle();
            alert(errorMessage);

            //mains not submit form
            return false;
        }

        showWaitingDialog();

        //jQuery Mobile bug: could not refresh page javascript event.
        //solution: use form submit method instead, and return false.
        $('#Form1')[0].submit();
        return false;
    });

    function reportSuccessAfterSubmit() {
        var $hidStatus = $('#HidStatus'),
            hidStatusValue = $hidStatus.val();

        //page load
        if (hidStatusValue === '') {
            return;
        }

        //after submit
        alert(hidStatusValue);
        $hidStatus.val('');
    }

    function showHospitalListForSelection() {
        var fullNameValue = arguments[0];

        $.ajax({
            type: 'post',
            dataType: 'json',
            contentType: "application/json; charset=utf-8",
            url: 'ChinaWechat/GetWechatInfoService.asmx/GetWechatInfo',
            data: "{ 'FullName': '" + fullNameValue + "' }",
            success: function (response) {
                if ($.parseJSON(response.d) == null) {
                    clearPage();
                    return;
                }

                var dataList = $.parseJSON(response.d).Table;

                createHospitalList({
                    dataList: dataList,
                    click: function () {
                        var $hospitalDiv = this,
                            index = $hospitalDiv.index(),
                            dataIndex = index - 1;

                        if (index === 0) {
                            return;
                        }

                        if (index === $hospitalDiv.parent('div').children().length - 1) {
                            $('#hospitalList').removeClass('show');
                            clearPage();
                            return;
                        }

                        $('#hospitalList').removeClass('show');
                        fillPage(dataList[dataIndex]);
                    }
                });
            },
            error: function (xhr) {
                alert("Error:" + xhr.responseText);
            }
        });
    }

    function createHospitalList() {
        var dataList = arguments[0].dataList,
            click = arguments[0].click;

        var html = '';

        for (var i in dataList) {
            if (!dataList.hasOwnProperty(i)) {
                continue;
            }

            html += '<div>' + dataList[i].Hospital + '-' + dataList[i].DepartmentZH + '</div>';
        }

        $('#hospitalList>div>div>div:not(:first-child):not(:last-child)').remove();
        $('#hospitalList>div>div>div:nth-child(1)').after(html);

        $('#hospitalList')
            .addClass('show')
            .undelegate()
            .delegate('>div>div>div', 'click', function (e) {
                e.stopPropagation();

                var $hospitalDiv = $(this);
                click.call($hospitalDiv);
            });
    }

    function getValidateErrorMessage() {
        var emailRegexp = /^([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+@([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+\.[a-zA-Z]{2,3}$/;
        var phoneRegexp = /^(?:13\d|15\d|17\d|18\d)\d{5}(\d{3}|\*{3})$|^((0\d{2,3})-)?(\d{7,8})(-(\d{3,}))?$|^$/;

        return reduceMessage([
            {
                condition: $('#txtFullName').val().trim() === '',
                message: $('#errMsgFullName').val()
            }, {
                condition: $('#txtHospital').val().trim() === '',
                message: $('#errMsgHospital').val()
            }, {
                condition: $('#dllDepartment').val().trim() === '',
                message: $('#errMsgDepartment').val()
            }, {
                condition: $('#dllProvince').val().trim() === '',
                message: $('#errMsgProvince').val()
            }, {
                condition: $('#txtCity').val().trim() === '',
                message: $('#errMsgCity').val()
            }, {
                condition: !emailRegexp.test($('#txtEmail').val().trim()),
                message: $('#errMsgEmail').val()
            }, {
                condition: !phoneRegexp.test($('#txtPhone').val().trim()),
                message: $('#errMsgPhone').val()
            }, {
                condition: $('#chkRelated').is(':checked') && $('#dllProduct').val().trim() === '',
                message: $('#errMsgProduct').val()
            }, {
                condition: $('#textDesc').val().trim() === '',
                message: $('#errMsgQuestion').val()
            }
        ]);
    }

    function reduceMessage(itemList) {
        var message = '';

        for (var i = 0; i < itemList.length; i++) {
            if (!itemList[i].condition) {
                continue;
            }

            message += itemList[i].message + '\n';
        }

        return message;
    }

    function showUserRequireInputStyle() {
        $('#txtFullName,#txtHospital,#txtCity,#txtEmail,#textDesc').each(function () {
            var textbox = $(this),
                isEmpty = textbox.val().trim() === '';

            isEmpty && textbox.addClass('requireUserInput');
        });

        //dropdown list: add class to its parent div, because jquery mobile would wrap it.
        $('#dllDepartment').val() === '' && $('#dllDepartment').parent('div').addClass('requireUserInput');
        $('#dllProvince').val() === '' && $('#dllProvince').parent('div').addClass('requireUserInput');
    }

    function showWaitingDialog() {
        $('#waiting').addClass('show');
    }

    function clearPage() {
        $('#dllDepartment').val('')
            .prev('span').text($('#dllDepartment').find('option:selected').text())
            .parent('div').removeClass('requireUserInput');

        $('#dllProvince').val('')
            .prev('span').text($('#dllProvince').find('option:selected').text())
            .parent('div').removeClass('requireUserInput');

        $('#txtHospital').val('').removeClass('requireUserInput');
        $('#txtCity').val('').removeClass('requireUserInput');
        $('#txtEmail').val('').removeClass('requireUserInput');
        $('#txtPhone').val('').removeClass('requireUserInput');
        $('#hidHCPID').val('').removeClass('requireUserInput');
    }

    function fillPage(data) {
        $('#dllDepartment').val(data.DepartmentEN)
            .prev('span').text(data.DepartmentZH)
            .parent('div').removeClass('requireUserInput');

        $('#dllProvince').val(data.Province)
            .prev('span').text(data.Province)
            .parent('div').removeClass('requireUserInput');

        $('#txtHospital').val(data.Hospital).removeClass('requireUserInput');
        $('#txtCity').val(data.City).removeClass('requireUserInput');
        $('#txtEmail').val(data.Email).removeClass('requireUserInput');
        $('#txtPhone').val(data.Phone).removeClass('requireUserInput');
        $('#hidHCPID').val(data.HcpID).removeClass('requireUserInput');
    }

    function filterHtmlLabel(input) {
        var regexp = /<|>/g;

        return input.replace(regexp, '');
    }
});