﻿$(document).ready(function () {
    $("#dRight").hide();
    $("#dDown").show();
    $("#dInfo").show();

    //set title multilingual
    $('title').html($('#pageHeader').text());
});

function hideColumnToggle() {
    //hide column toggle buttons
    $('.ui-table-columntoggle-btn').hide();
}

function getQueryStringByName(name) {

    var result = location.search.match(new RegExp("[\?\&]" + name + "=([^\&]+)", "i"));

    if (result == null || result.length < 1) {

        return "";

    }

    return result[1];

}
function goBack() {
    history.back();
}