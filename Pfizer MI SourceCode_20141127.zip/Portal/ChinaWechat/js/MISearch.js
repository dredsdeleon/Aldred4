﻿$(function () {
    var queryObject = window.queryObject;

    //set title multilingual
    $('title').html($('#pageHeader').text());

    //false mains do not show block UI
    getSearchResultData(fillResultTable, false);

    $('#btnSubmit').click(function () {
        var dateRange = getDateRange();

        $('#keyword').val(filterHtmlLabel($('#keyword').val()));
        $('#searchResultTable').children().remove();

        //true mains show block UI
        getSearchResultData(fillResultTable, true);

        return false;
    });

    $('#searchResultTable').delegate('>tbody>tr>td>span', 'click', function (e) {
        var span = $(this),
            questionId = span.parent('td').parent('tr').attr('data-questionId');

        e.stopPropagation();
        location.href = 'ChinaWechatMISearchResultDetail.aspx?id=' + questionId;
    });

    // tool functions are as follow
    function getSearchResultData(success, showBlockUI) {
        var dateRange = getDateRange();

        $.ajax({
            type: "POST",
            url: "ChinaWeChat/ChinaWeChat.ashx?action=search",
            data: {
                openid: queryObject['openid'],
                NTID: queryObject['ntid'],
                startdate: dateRange.startDate,
                enddate: dateRange.endDate,
                keyword: $('#keyword').val().trim(),
                status: $('#ddlStatus').val().trim()
            },
            dataType: "json",
            beforeSend: showBlockUI ? blockUI : null,
            complete: showBlockUI ? unblockUI : null,
            success: function (response) {
                if (response == null) {
                    return;
                }

                success(response);
            }
        });
    }

    function fillResultTable(response) {
        var dateRegexp = /^(\d{2}\/\d{2})\/(\d{4})$/;

        $('#searchResultTable').html(_.reduce(response.Table, function (m, v) {
            var date = v.CreatedOnDate,
                fullName = v.HcpFullName,
                question = (
                    v.Question.length <= 42
                        ? v.Question
                        : v.Question.slice(0, 42) + '...'
                ),
                questionId = v.WechatMIQuestionID,

                match = dateRegexp.exec(date),
                monthDay = match[1],
                year = match[2];

            return m
                + '<tr data-questionId="' + questionId + '">\
                    <td>\
                        <span>' + fullName + '</span>\
                        <span>' + monthDay + '</span>\
                        <span>' + year + '</span>\
                    </td>\
                    <td>\
						<span>' + question + '</span>\
					</td>\
                </tr>';
        }, ''));
    }

    function blockUI() {
        $('#waiting').addClass('show');
    }

    function unblockUI() {
        $('#waiting').removeClass('show');
    }

    function getDateRange() {
        var range = $('#ddlRange').val().trim(),

            date = new Date(),
            year = date.getFullYear(),
            month = date.getMonth() + 1,
            day = date.getDate();

        //range=='$' mains this month.
        if (range === '$') {
            return {
                startDate: month + '/' + 1 + '/' + year,
                endDate: month + '/' + day + '/' + year
            };
        }

        //range=='*' mains six months ago.
        if (range === '*') {
            return {
                startDate: '1/1/1970',
                endDate: (month - 6 < 1 ? month + 12 - 6 : month - 6) + '/' + day + '/' + (month - 6 < 1 ? year - 1 : year)
            };
        }

        //range=='x' mains last x months. 
        return {
            startDate: (month - +range < 1 ? month + 12 - +range : month - +range) + '/' + day + '/' + (month - +range < 1 ? year - 1 : year),
            endDate: month + '/' + day + '/' + year
        };
    }

    function filterHtmlLabel(input) {
        var regexp = /<|>/g;

        return input.replace(regexp, '');
    }
});