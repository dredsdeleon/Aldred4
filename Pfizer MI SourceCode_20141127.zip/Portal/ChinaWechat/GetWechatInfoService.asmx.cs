﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using ChinaHcp.DataAccess.ChinaWechat;

namespace ChinaHcp.Web.Portal.Javascript.ChinaWechat
{
    /// <summary>
    /// GetWechatInfoService 的摘要说明
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // 若要允许使用 ASP.NET AJAX 从脚本中调用此 Web 服务，请取消对下行的注释。
    [System.Web.Script.Services.ScriptService]
    public class GetWechatInfoService : System.Web.Services.WebService
    {

        [WebMethod]
        public string GetWechatInfo(string FullName)
        {
            try
            {
                var da = new WechatAccess();
                return da.GetWechatInfo(FullName);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
