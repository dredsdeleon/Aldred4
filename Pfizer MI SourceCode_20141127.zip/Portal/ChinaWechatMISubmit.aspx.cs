﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ChinaHcp.DataAccess.ChinaWechat;
using ChinaHcp.DataAccess.ChinaWechat.Model;
using System.Resources;
using System.Security;
using System.Security.Cryptography;
using System.Text;
using System.IO;

namespace ChinaHcp.Web.Portal.ChinaWechat
{
    public partial class MISubmit : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            try
            {
                if (!Page.IsPostBack)
                {
                    //read count
                    int count;
                    string path = Server.MapPath(System.Web.HttpContext.Current.Request.ApplicationPath.ToString()) + "/ChinaWechat/count.txt";

                    if (!File.Exists(path))
                    {
                        StreamWriter sw=File.CreateText(path);
                        count = 1;
                        sw.Write(count);
                        sw.Close();
                    }
                    else
                    {
                        string temp = File.ReadAllText(path);
                        count = Int32.Parse(temp);
                        count++;
                        //write to file
                        File.WriteAllText(path, count.ToString());
                    }
                }
            }
            catch { }
            //Response.End();


            
            //restrict browser
            string currentBrowser = Request.UserAgent.ToString().ToLower();

            if (currentBrowser.IndexOf("micromessenger") <= 0)
            {
                Response.Redirect("ChinaWechatError.htm?Error=" + GetLocalResourceObject("errMsg").ToString() + GetLocalResourceObject("errBrowser").ToString());
                //Response.End();
            }
           

            //restrict forward
            if (Request.QueryString["from"] != null && !string.IsNullOrEmpty(Request.QueryString["from"].ToString()))
            {
                Response.Redirect("ChinaWechatError.htm?Error=" + GetLocalResourceObject("errMsg").ToString() + GetLocalResourceObject("errForward").ToString());
                //Response.End();            
            }

            if (!Page.IsPostBack)
            {


                
                //Get url parameters

                if (Request.QueryString["NTID"] != null && !string.IsNullOrEmpty(Request.QueryString["NTID"].ToString()))
                {
                    hidNTID.Value = Request.QueryString["NTID"].ToString();
                }
                if (Request.QueryString["email"] != null && !string.IsNullOrEmpty(Request.QueryString["email"].ToString()))
                {
                    hidEmail.Value = Request.QueryString["email"].ToString();
                }
                if (Request.QueryString["openid"] != null && !string.IsNullOrEmpty(Request.QueryString["openid"].ToString()))
                {
                    hidOpenID.Value = Request.QueryString["openid"].ToString();
                }
                if (Request.QueryString["code"] != null && !string.IsNullOrEmpty(Request.QueryString["code"].ToString()))
                {
                    hidCode.Value = Request.QueryString["code"].ToString();
                }
                if (string.IsNullOrEmpty(hidNTID.Value) || string.IsNullOrEmpty(hidEmail.Value) || string.IsNullOrEmpty(hidOpenID.Value) || !checkPara(hidNTID.Value, hidOpenID.Value, hidEmail.Value, hidCode.Value))
                {
                    //HidStatus.Value = GetLocalResourceObject("errMsg").ToString() + GetLocalResourceObject("errPara").ToString();
                    Response.Redirect("ChinaWechatError.htm?Error=" + GetLocalResourceObject("errMsg").ToString() + GetLocalResourceObject("errPara").ToString());
                    //Response.End();
                }
            }
            else
            {
                if (string.IsNullOrEmpty(hidNTID.Value) || string.IsNullOrEmpty(hidEmail.Value) || string.IsNullOrEmpty(hidOpenID.Value) || !checkPara(hidNTID.Value, hidOpenID.Value, hidEmail.Value, hidCode.Value))
                {
                    //HidStatus.Value = GetLocalResourceObject("errMsg").ToString() + GetLocalResourceObject("errPara").ToString();
                    Response.Redirect("error.htm?Error=" + GetLocalResourceObject("errMsg").ToString() + GetLocalResourceObject("errPara").ToString());
                    //Response.End();
                }
                SubimtWebchatInfo();
            }
            try
            {
                BindDropDownList();
                //clear dropdown list after binding
                dllProvince.SelectedIndex = 0;
                dllDepartment.SelectedIndex = 0;
            }
            catch (Exception ex)
            {
                ChinaWechatUtility.LogMessage(ex.Message, hidNTID.Value);
                HidStatus.Value = GetLocalResourceObject("errMsg").ToString() + "\r" + ex.Message;
          
            }
        }

        private bool checkPara(string NTID, string openid,string email,string code)
        { 
            MD5CryptoServiceProvider md5=new MD5CryptoServiceProvider();
            string strInput=openid+NTID+email+"imslscl";


            byte[] byteInput = System.Text.Encoding.Default.GetBytes(strInput);
            byte[] byteOutput = md5.ComputeHash(byteInput);
            string strOutput = "";
            for (int i=0; i < byteOutput.Length; i++)
            {
                strOutput += byteOutput[i].ToString("x2");
            }
            //HidStatus.Value = strOutput;
            if (strOutput == code)
                return true;
            else
                return false;
        
        }
        private void BindDropDownList()
        {
            var da = new WechatAccess();
            dllProduct.DataSource = da.GetMITradeProduct();
            dllProduct.DataValueField = "ProductID"; ;
            dllProduct.DataTextField = "TradeNameZH";

            dllProduct.DataBind();
            dllProduct.Items.Insert(0, (new ListItem(GetLocalResourceObject("Select").ToString(), "")));
            //dllProduct.Items.Insert(0, (new ListItem("NO PRODUCT – CN", "")));

            dllDepartment.DataSource = da.GetSpecialty();
            dllDepartment.DataValueField = "NameEN";
            dllDepartment.DataTextField = "NameZH";
            dllDepartment.DataBind();
            dllDepartment.Items.Insert(0, (new ListItem(GetLocalResourceObject("Select").ToString(), "")));

            dllProvince.DataSource = da.GetProvince();
            dllProvince.DataValueField = "NameCHS";
            dllProvince.DataTextField = "NameCN";
            dllProvince.DataBind();
            dllProvince.Items.Insert(0, (new ListItem(GetLocalResourceObject("Select").ToString(), "")));
        }

        private void SubimtWebchatInfo()
        {
            try
            {
                WechatMIQuestion wechatInfo = new WechatMIQuestion();
                wechatInfo.NTID = hidNTID.Value;
                wechatInfo.Email = hidEmail.Value;
                if (string.IsNullOrEmpty(hidNTID.Value))
                    wechatInfo.HcpID = string.Empty;
                else
                    wechatInfo.HcpID = hidHCPID.Value;

                if (string.IsNullOrEmpty(hidNTID.Value) || string.IsNullOrEmpty(hidEmail.Value) || string.IsNullOrEmpty(hidOpenID.Value))
                {
                    HidStatus.Value = GetLocalResourceObject("Failed").ToString() + "\r" + GetLocalResourceObject("errPara").ToString();
                }
                else
                {
                    wechatInfo.HcpFullName = txtFullName.Text.Trim();
                    wechatInfo.HcpHospital = txtHospital.Text.Trim();
                    wechatInfo.HcpDepartment = dllDepartment.SelectedItem.Text.ToString();
                    wechatInfo.HcpDeptCode = dllDepartment.SelectedValue.ToString();
                    wechatInfo.HcpProvince = dllProvince.SelectedItem.Text.ToString();
                    wechatInfo.HcpProvinceCHS = dllProvince.SelectedValue.ToString();
                    wechatInfo.HcpCity = txtCity.Text.Trim();
                    wechatInfo.HcpEmail = txtEmail.Text.Trim();
                    wechatInfo.HcpPhone = txtPhone.Text.Trim();

                    if (hidProdRelated.Value == "Yes")
                    {
                        wechatInfo.WechatMIQuestionID = dllProduct.SelectedValue.ToString().Substring(0, 36);
                        wechatInfo.ProductCode = dllProduct.SelectedValue.ToString().Substring(36);
                        wechatInfo.ProductNameZH = dllProduct.SelectedItem.ToString();
                    }
                    else
                    {
                        wechatInfo.WechatMIQuestionID = string.Empty;
                        wechatInfo.ProductCode = "NO PRODUCT - CN";
                        wechatInfo.ProductNameZH = "非产品";
                    }
                    /*
                    Response.Write(wechatInfo.HcpDeptCode);
                    Response.Write(wechatInfo.HcpDepartment);
                    Response.Write(wechatInfo.HcpProvince);
                    Response.Write(wechatInfo.HcpProvinceCHS);

                    Response.Write("</br>");
                    Response.Write(wechatInfo.ProductCode);
                    Response.Write(hidProdRelated.Value);
                    wechatInfo.ProductCode = dllProduct.SelectedItem.ToString();
                    wechatInfo.ProductNameZH = dllProduct.SelectedItem.ToString();
                    */
                    wechatInfo.Question = textDesc.Value.Trim();
                    wechatInfo.CreatedBy = hidOpenID.Value;
                    wechatInfo.ModifiedBy = hidOpenID.Value;

                    WechatAccess webchat = new WechatAccess();
                    int result=webchat.SaveWechatInfo(wechatInfo);
                    if (result == -1)
                        HidStatus.Value = GetLocalResourceObject("Success").ToString();
                    else
                    {
                        HidStatus.Value = GetLocalResourceObject("Failed").ToString() + "\r错误码：" + result.ToString();
                        ChinaWechatUtility.LogMessage(GetLocalResourceObject("Failed").ToString() + "\r错误码：" + result.ToString(), hidNTID.Value);

                    }


                    //HidStatus.Value = wechatInfo.HcpDeptCode + wechatInfo.HcpDepartment + wechatInfo.HcpProvince + wechatInfo.HcpProvinceCHS;
                }
                ClearForm();
            }
            catch (Exception ex)
            {
                ClearForm();
                ChinaWechatUtility.LogMessage(ex.Message, hidNTID.Value);
                HidStatus.Value = GetLocalResourceObject("Failed").ToString() + "\r" + ex.Message;
                //throw ex;
            }
        }
        private void ClearForm()
        {
            txtCity.Text = "";
            txtEmail.Text = "";
            txtFullName.Text = "";
            txtHospital.Text = "";
            txtPhone.Text = "";
            dllProvince.SelectedIndex = 0;
            dllDepartment.SelectedIndex = 0;
            dllProduct.SelectedIndex = 0;
            textDesc.Value = "";
            hidHCPID.Value = "";
            hidProdRelated.Value = "No";
        }
    }
}
