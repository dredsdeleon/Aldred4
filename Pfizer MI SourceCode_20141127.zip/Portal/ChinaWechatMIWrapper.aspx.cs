﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ChinaHcp.Web.Portal
{
    public partial class ChinaWechatMIWrapper : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            ForwardErrorMessage.Value = GetLocalResourceObject("errMsg").ToString() + GetLocalResourceObject("errForward").ToString();
            ParameterErrorMessage.Value = GetLocalResourceObject("errMsg").ToString() + GetLocalResourceObject("errPara").ToString(); ;
        }
    }
}