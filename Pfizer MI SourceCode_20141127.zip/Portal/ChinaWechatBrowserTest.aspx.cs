﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.IO;

namespace ChinaHcp.Web.Portal
{
    public partial class ChinaWechatBrowserTest : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //Response.Write(Request.UserAgent);
            //string currentBrowser = Request.UserAgent.ToString().ToLower();

            //if (currentBrowser.IndexOf("micromessenger") > 0)
            //{
            //    Response.Write("YES");
            //}
            //else 
            //{
            //    Response.Write("NO");

            //}

            try
            {
                string path = Server.MapPath(System.Web.HttpContext.Current.Request.ApplicationPath.ToString()) + "/ChinaWechat/count.txt";
                string temp = File.ReadAllText(path);
                lblBrowser.Text = "阅读数： " + temp;
                logfile.NavigateUrl = ConfigurationManager.AppSettings["ChinaWechatLogFile"].ToString();

            }
            catch (Exception ex)
            {
                Response.Write("出错了： " + ex.Message.ToString());
            }
        }
    }
}
