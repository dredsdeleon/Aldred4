﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ChinaWechat.BLL;

namespace ChinaWechat
{
    public class ChinaWechatJob: Quartz.IJob
    {
        public ChinaWechatJob()
        {
        }

        public void Execute(Quartz.IJobExecutionContext context)
        {
            MainChinaWeChatBLL mainProcess = new MainChinaWeChatBLL();
            mainProcess.MainChianWeChatProcess();
        }
    }
}
