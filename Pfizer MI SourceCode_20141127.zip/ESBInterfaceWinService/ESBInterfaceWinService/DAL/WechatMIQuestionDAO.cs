﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using ChinaWechat.Utility;

namespace ChinaWechat.DAL
{
    public class WechatMIQuestionDAO :DaoBase
    {
        public WechatMIQuestionDAO() : base()
        {}

        public DataTable GetWechatMIQuestionData() 
        {
            try
            {
                SqlConnection conn = GetConnection();
                var ds = SqlHelper.ExecuteDataset(conn, CommandType.Text, "SELECT * FROM view_ChinaWechatQuestion");
                conn.Close();
                conn.Dispose();
                return ds.Tables[0];
            }
            catch (Exception e)
            {
                AppLog.Write("Error: Can not get data from WechatMIQuestion table");
                throw e;
            }
        }

        public int UpdateStatus4WechatMIQuestionData(string questionUID, int sendStatus)
        {
            int result = 0;
            try
            {
                SqlConnection conn = GetConnection();
                result = SqlHelper.ExecuteNonQuery(conn, CommandType.Text, "UPDATE WechatMIQuestion SET ModifiedBy = 'ChinaWechat.Service',ModifiedOn =GETDATE(), sendStatus = " + sendStatus + " WHERE QuestionUID = '" + questionUID+"'");
                conn.Close();
                conn.Dispose();
            }
            catch (Exception e)
            {
                AppLog.Write("Error: Can not change status to " + sendStatus + " for WechatMIQuestion QuestionUID is " + questionUID);
                AppLog.Write("Error Details:" +e.Message);
            }
            return result;
        }
    }
}
