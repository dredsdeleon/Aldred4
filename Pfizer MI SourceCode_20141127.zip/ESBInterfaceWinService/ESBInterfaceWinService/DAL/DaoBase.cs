﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Configuration;
using ChinaWechat.Utility;

namespace ChinaWechat.DAL
{
    public class DaoBase
    {
        //public static string DatabaseConnString = Properties.Settings.Default.FSRValuationRequestsConnectionString;
        String DatabaseConnString = ConfigurationManager.ConnectionStrings["ESBInterface"].ToString();
        public DaoBase()
        {
        }
        public SqlConnection GetConnection()
        {
            try
            {
                SqlConnection conn = new SqlConnection(DatabaseConnString);
                return conn;
            }
            catch (Exception e)
            {
                AppLog.Write("Error: Can not open ChinaHCP connection");
                throw e;
            }
        }
    }
}
