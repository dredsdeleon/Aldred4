﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ChinaWechat.ViewModel
{
    public enum SendStatus
    {
        UNSEND =0,
        SUCCESS,
        ERROR,
        DUPLICATE
    }
}
