﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ChinaWechat.DAL;
using System.Data;

namespace ChinaWechat.BLL
{
    public class WechatMIQuestionBLL
    {
        public WechatMIQuestionBLL()
        { 
        
        }

        WechatMIQuestionDAO wDao= new WechatMIQuestionDAO();

        public DataTable GetWechatMIQuestionData()
        {
            return wDao.GetWechatMIQuestionData();
        }

        public int UpdateStatus4WechatMIQuestionData(string questionUID, int sendStatus)
        {
            return wDao.UpdateStatus4WechatMIQuestionData(questionUID, sendStatus);
        }

    }
}
