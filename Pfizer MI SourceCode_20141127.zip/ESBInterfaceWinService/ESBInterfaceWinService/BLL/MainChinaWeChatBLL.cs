﻿#define DEBUG
#undef DEBUG
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ChinaWechat.Utility;
using System.Data;
using ChinaWechat.ViewModel;
using System.Configuration;



namespace ChinaWechat.BLL
{

    public class MainChinaWeChatBLL
    {
        public MainChinaWeChatBLL() { }

        public void MainChianWeChatProcess()
        {
            DataTable WechatMIQuestionData = null;
            WechatMIQuestionBLL wchatMIQuestionbll = new WechatMIQuestionBLL();
           
            #if DEBUG
                AppLog.Write("-----Start to get data from ChinaHCP database-----");
            #endif
            try
            {
                WechatMIQuestionData = wchatMIQuestionbll.GetWechatMIQuestionData();
            }
            catch (Exception e)
            {
                AppLog.Write("-----Fail to get data from the ChinaHCP database-----");
                AppLog.Write("Error Details:" + e.Message);
            }

            if (WechatMIQuestionData.Rows.Count > 0)
            {
                ChinaWechat.MedicalInquiryService.MedicalInquiryServicev2c miService = new MedicalInquiryService.MedicalInquiryServicev2c();
                miService.Credentials = System.Net.CredentialCache.DefaultNetworkCredentials;
                //miService.Credentials = new System.Net.NetworkCredential("WECHATCHI_AdmPx", "Mnop1234ekMM", "");
                miService.Credentials = new System.Net.NetworkCredential(ConfigurationManager.AppSettings.Get("ESBUserName"), ConfigurationManager.AppSettings.Get("ESBPassword"), ""); 
                
                try
                {
                    #if DEBUG
                        AppLog.Write("-----Begin to send data to ESB Service-----");
                    #endif
                    foreach (DataRow row in WechatMIQuestionData.Rows)
                    {
                        try
                        {
                            #region Call Web Service
                            ChinaWechat.MedicalInquiryService.RequestMessage primaRequestMessage = new ChinaWechat.MedicalInquiryService.RequestMessage();
                            ChinaWechat.MedicalInquiryService.M2MRecordType m2MRecord = new ChinaWechat.MedicalInquiryService.M2MRecordType();
                            ChinaWechat.MedicalInquiryService.M2MUser m2MUser = new ChinaWechat.MedicalInquiryService.M2MUser();
                            ChinaWechat.MedicalInquiryService.Customers customers = new ChinaWechat.MedicalInquiryService.Customers();
                            ChinaWechat.MedicalInquiryService.CustomersCustomer customer = new ChinaWechat.MedicalInquiryService.CustomersCustomer();
                            ChinaWechat.MedicalInquiryService.MedicalInquiry medicalInquiry = new ChinaWechat.MedicalInquiryService.MedicalInquiry();

                            //Data for sales, lastname, officephone, role is not available this time
                            m2MUser.ID = row["NTID"].ToString();
                            m2MUser.LastName = row["FullName"].ToString();
                            m2MUser.Email = row["Email"].ToString();
                            m2MUser.OfficePhone = row["Phone"].ToString();
                            m2MUser.Role = row["Department"].ToString();

                            customer.Email = row["HcpEmail"].ToString();
                            customer.LastName = row["HcpFullName"].ToString();
                            customer.City = row["HcpCity"].ToString();
                            customer.State = row["HcpProvinceCHS"].ToString();
                            customer.Specialty = row["HcpDeptCode"].ToString();
                            customer.Company = row["HcpHospital"].ToString();
                            customer.OfficePhone = row["HcpPhone"].ToString();
                            customer.Country = "CN";
                            customer.Language = "Chinese";

                            medicalInquiry.SourceSystem = "HCP Website";
                            medicalInquiry.ID = row["QuestionUID"].ToString();
                            medicalInquiry.ProductCode = row["ProductCode"].ToString();
                            medicalInquiry.CreatedDate = Convert.ToDateTime(row["CreatedDateET"]);
                            medicalInquiry.Inquiry = row["Question"].ToString();

                            customers.Customer = customer;
                            m2MRecord.Customers = customers;
                            m2MRecord.M2MUser = m2MUser;
                            m2MRecord.MedicalInquiry = medicalInquiry;
                            primaRequestMessage.M2MRecord = m2MRecord;

                            ChinaWechat.MedicalInquiryService.ResponseMessage primaryResponseMessage = miService.process(primaRequestMessage);

                            #endregion

                            #region SendStatus log
                            if (primaryResponseMessage != null)
                            {
                                if (primaryResponseMessage.result.ToLower() == "success")
                                {
                                    #if DEBUG
                                        AppLog.Write("WechatMIQuestionID:" + row["WechatMIQuestionID"].ToString());
                                        AppLog.Write("QuestionUID:" + row["QuestionUID"].ToString());
                                        AppLog.Write("Response Status: Success");
                                    #endif
                                    wchatMIQuestionbll.UpdateStatus4WechatMIQuestionData(row["QuestionUID"].ToString(), (int)SendStatus.SUCCESS);
                                }
                                else if (primaryResponseMessage.result.ToLower() == "error")
                                {
                                    AppLog.Write("WechatMIQuestionID:" + row["WechatMIQuestionID"].ToString());
                                    AppLog.Write("QuestionUID:" + row["QuestionUID"].ToString());
                                    AppLog.Write("Response Status: Error");
                                    wchatMIQuestionbll.UpdateStatus4WechatMIQuestionData(row["QuestionUID"].ToString(), (int)SendStatus.ERROR);
                                }
                                else if (primaryResponseMessage.result.ToLower() == "duplicate")
                                {
                                    AppLog.Write("WechatMIQuestionID:" + row["WechatMIQuestionID"].ToString());
                                    AppLog.Write("QuestionUID:" + row["QuestionUID"].ToString());
                                    AppLog.Write("Response Status: Duplicate");
                                    wchatMIQuestionbll.UpdateStatus4WechatMIQuestionData(row["QuestionUID"].ToString(), (int)SendStatus.DUPLICATE);
                                }
                                else
                                {
                                    AppLog.Write("WechatMIQuestionID:" + row["WechatMIQuestionID"].ToString());
                                    AppLog.Write("QuestionUID:" + row["QuestionUID"].ToString());
                                    AppLog.Write("Exception Status: Can not get any status from ESB service");
                                    wchatMIQuestionbll.UpdateStatus4WechatMIQuestionData(row["QuestionUID"].ToString(), (int)SendStatus.ERROR);
                                }
                            }
                            else
                            {
                                AppLog.Write("WechatMIQuestionID:" + row["WechatMIQuestionID"].ToString());
                                AppLog.Write("QuestionUID:" + row["QuestionUID"].ToString());
                                AppLog.Write("Exception Status: Can not get any status from ESB service");
                                wchatMIQuestionbll.UpdateStatus4WechatMIQuestionData(row["QuestionUID"].ToString(), (int)SendStatus.ERROR);

                            }
                            #endregion
                        }
                        catch (Exception e)
                        {
                            AppLog.Write("-----Fail to send data to ESB Service-----");
                            AppLog.Write("WechatMIQuestionID:" + row["WechatMIQuestionID"].ToString());
                            AppLog.Write("QuestionUID:" + row["QuestionUID"].ToString());
                            AppLog.Write("Error Details:" + e.Message);
                            wchatMIQuestionbll.UpdateStatus4WechatMIQuestionData(row["QuestionUID"].ToString(), (int)SendStatus.ERROR);
                        }
                    }
                }

                catch (Exception ex)
                {
                    AppLog.Write("-----Fail to connect to ESB Service-----");
                    AppLog.Write("Error Details:" + ex.Message);
                }
                

            }
        }
    }
}
