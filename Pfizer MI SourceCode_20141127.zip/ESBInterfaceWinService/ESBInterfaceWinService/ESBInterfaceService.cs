﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using ChinaWechat.Utility;
using Quartz;
using Quartz.Impl;

namespace ChinaWechat
{
    public partial class ESBInterfaceService : ServiceBase
    {
        public ESBInterfaceService()
        {
            InitializeComponent();
        }

        private IScheduler _Sched;

        protected override void OnStart(string[] args)
        {
            AppLog.Init();
            AppLog.Write("-----ChinaWechat.Service starts-----");
            try
            {
                // construct a scheduler factory
                ISchedulerFactory schedFact = new StdSchedulerFactory();
                // get a scheduler
                _Sched = schedFact.GetScheduler();
                _Sched.Start();
            }
            catch (Exception e)
            {
                AppLog.Write("Error: Can not Start ChinaWechatJob");
                AppLog.Write("Error Details:" + e.Message);
            }
        }

        protected override void OnStop()
        {
            if (_Sched != null)
            {
                _Sched.Shutdown(true);
            }
            AppLog.Write("-----ChinaWechat.Service ends-----");
        }
    }
}
